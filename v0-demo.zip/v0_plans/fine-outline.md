# Velocity Merchant Onboarding - Implementation Plan

## Current State Analysis
- ✅ Welcome page (`/app/page.tsx`) - Complete with form validation, Google OAuth simulation, and TOS/Privacy gates
- ✅ OnboardingContext (`/lib/onboarding-context.tsx`) - Fully implemented with state management, auto-save, and localStorage persistence
- ✅ Types (`/lib/types.ts`) - Complete with all necessary interfaces and mock product data
- ✅ Step Indicator component - Built with progress bar, step circles, and clickable navigation
- ✅ Save Toast component - Implemented with status indicators (saving/saved/error/idle)
- ✅ Step 1 - Integrations - Complete with toggleable integrations (Shopify, Stripe, PayPal, Google Ads)
- ✅ Step 2 - Tracking - Complete with Meta Pixel ID, Google Conversion ID, and subdomain fields
- ❌ Missing: Step 3 - Products component
- ❌ Missing: Step 4 - Assets component
- ❌ Missing: `/app/onboarding/page.tsx` - Wizard wrapper to orchestrate steps
- ❌ Missing: `/app/onboarding/layout.tsx` - Layout with StepIndicator
- ❌ Missing: `/app/portal/**` - All portal pages and sidebar
- ❌ Missing: OnboardingProvider wrap in root layout

## Implementation Plan

### Phase 1: Complete Onboarding Wizard (Steps 3 & 4 + Wrapper)

#### 1.1 Create Step 3 - Products Component (`/components/onboarding/step-products.tsx`)
- Display collapsible product categories (Electronics, Apparel, Home & Kitchen, Health)
- Checkboxes to select/deselect products within each category
- Show product name, price, and SKU
- Track selected count
- "Back", "Skip for now", "Continue" buttons
- Auto-save on product selection changes

#### 1.2 Create Step 4 - Assets Component (`/components/onboarding/step-assets.tsx`)
- File upload area for brand materials (logo, brand guidelines)
- Optional file uploads (not required to complete)
- "Back", "Continue" buttons (no skip on step 4)
- "Go to my portal" button instead of "Continue" after completion
- Auto-save on file uploads (simulate with URL generation)

#### 1.3 Create Onboarding Wizard Wrapper (`/app/onboarding/page.tsx`)
- Render StepIndicator at top
- Conditionally render appropriate step component based on currentStep
- Pass required props to each step: saveStatus, lastSavedAt, nextStep, prevStep, completeStep
- SaveToast component to show auto-save status
- Protected route: redirect to "/" if no account created

#### 1.4 Create Onboarding Layout (`/app/onboarding/layout.tsx`)
- Basic layout with proper padding/max-width
- Wrap with OnboardingProvider if not already provided
- Center the step content

#### 1.5 Update Root Layout (`/app/layout.tsx`)
- Add OnboardingProvider to wrap the entire app for persistent state management

### Phase 2: Build Portal Section

#### 2.1 Create Portal Sidebar (`/components/portal/sidebar.tsx`)
- Fixed left sidebar with logo at top
- Navigation menu items: Dashboard, Funnels, Experiments, Products, Offers
- Settings submenu with: Integrations, Domain, Tracking, Brand
- Reporting submenu with: Performance, Insights
- Active state indicators
- Hover effects for interactivity

#### 2.2 Create Portal Layout (`/app/portal/layout.tsx`)
- Sidebar on left + main content area on right
- Use flexbox layout
- Responsive: sidebar collapses on mobile (or drawer navigation)
- Protected route: redirect to "/" if no account created

#### 2.3 Create Portal Dashboard Page (`/app/portal/page.tsx`)
- Display merchant account info (company name, operating name, email, website)
- Mock metrics section: Revenue, Conversion Rate, AOV
- Recent funnels list (mock data)
- Quick setup checklist with integration statuses
- Display last saved timestamp from onboarding

#### 2.4 Create Portal Stub Pages
- Create `/app/portal/funnels/page.tsx` - "Funnels" placeholder
- Create `/app/portal/experiments/page.tsx` - "Experiments" placeholder
- Create `/app/portal/products/page.tsx` - "Products" placeholder
- Create `/app/portal/offers/page.tsx` - "Offers" placeholder
- Create `/app/portal/settings/[section]/page.tsx` - Settings dynamic route
- Create `/app/portal/reporting/[section]/page.tsx` - Reporting dynamic route

### Phase 3: Navigation & Polish

#### 3.1 Update Welcome Form Navigation
- Ensure redirect to `/onboarding` after account creation (already done)
- Add redirect to `/portal` if account already exists

#### 3.2 Add Portal Navigation in Onboarding Wizard Step 4
- After "Go to my portal" button click on Step 4, redirect to `/portal`
- Mark step 4 as complete before redirecting

#### 3.3 Testing & Validation
- Test Welcome → Onboarding → Portal flow
- Verify auto-save works for all steps
- Test free navigation between steps
- Verify localStorage persistence
- Test mobile responsiveness (375px+)
- Ensure all buttons work correctly (Back, Skip, Continue, Go to Portal)

## Key Implementation Details

### Auto-Save Behavior
- Already implemented in context with 2s debounce
- Trigger on any field change in steps
- Show "Saving..." → "Saved" → "Last saved [time]" flow
- Error state persists until resolved

### Data Persistence
- All state stored in localStorage under "velocity_onboarding" key
- Account info persists across page reloads
- User can resume onboarding at any point
- Portal should display persisted account data

### Component Props Pattern (Steps)
```typescript
interface StepProps {
  nextStep: () => void;
  prevStep: () => void;
  saveStatus: SaveStatus;
  lastSavedAt: Date | null;
}
```

### Design System (Already Configured)
- Colors: Black/white theme (oklch format)
- Typography: Geist (sans) + Geist Mono
- Spacing: Tailwind scale (p-4, gap-6, etc.)
- Components: shadcn/ui (Button, Input, Checkbox, Card, Badge, etc.)

## File Dependencies
- `/components/onboarding/step-products.tsx` → uses `useOnboarding`, `Button`, `Checkbox`, `Card`
- `/components/onboarding/step-assets.tsx` → uses `useOnboarding`, `Button`, `Input`
- `/app/onboarding/page.tsx` → imports all 4 steps, StepIndicator, SaveToast
- `/components/portal/sidebar.tsx` → uses `Button`, navigation icons, responsive logic
- `/app/portal/layout.tsx` → imports Sidebar, OnboardingProvider
- `/app/portal/page.tsx` → uses `useOnboarding`, displays account + mock data

## Success Criteria
- Complete flow from Welcome → Onboarding Wizard (4 steps) → Portal Dashboard
- All 4 wizard steps render and save data correctly
- Portal sidebar navigation works
- Auto-save indicator displays correctly
- Mobile responsive at 375px+
- No console errors
- State persists across page reloads
