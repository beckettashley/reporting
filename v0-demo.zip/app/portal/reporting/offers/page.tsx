"use client";

import { Badge } from "@/components/ui/badge";
import { DataTable, DataTableColumn } from "@/components/ui/data-table";

interface OfferReport {
  id: string;
  name: string;
  redemptions: number;
  revenue: string;
  revenueNum: number;
  status: "active" | "inactive";
}

const OFFER_REPORTS: OfferReport[] = [
  { id: "offer-001", name: "Summer Sale 20% Off", redemptions: 342, revenue: "$12,450", revenueNum: 12450, status: "active" },
  { id: "offer-002", name: "Skincare Bundle Deal", redemptions: 156, revenue: "$8,320", revenueNum: 8320, status: "active" },
  { id: "offer-003", name: "Free Serum with Purchase", redemptions: 89, revenue: "$4,100", revenueNum: 4100, status: "inactive" },
  { id: "offer-004", name: "Holiday Free Shipping", redemptions: 0, revenue: "$0", revenueNum: 0, status: "inactive" },
  { id: "offer-005", name: "New Customer Discount", redemptions: 234, revenue: "$9,800", revenueNum: 9800, status: "active" },
  { id: "offer-006", name: "Flash Sale 40% Off", redemptions: 567, revenue: "$18,200", revenueNum: 18200, status: "inactive" },
  { id: "offer-007", name: "VIP Early Access", redemptions: 78, revenue: "$5,600", revenueNum: 5600, status: "active" },
  { id: "offer-008", name: "Birthday Special", redemptions: 123, revenue: "$3,450", revenueNum: 3450, status: "active" },
];

const getStatusBadge = (status: OfferReport["status"]) => {
  switch (status) {
    case "active":
      return (
        <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30">
          Active
        </Badge>
      );
    case "inactive":
      return (
        <Badge variant="outline" className="bg-muted text-muted-foreground border-border">
          Inactive
        </Badge>
      );
  }
};

const columns: DataTableColumn<OfferReport>[] = [
  {
    key: "name",
    header: "Offer Name",
    sortable: true,
  },
  {
    key: "redemptions",
    header: "Redemptions",
    sortable: true,
    render: (offer) => <span className="tabular-nums">{offer.redemptions.toLocaleString()}</span>,
  },
  {
    key: "revenueNum",
    header: "Revenue",
    sortable: true,
    render: (offer) => <span className="tabular-nums">{offer.revenue}</span>,
  },
  {
    key: "status",
    header: "Status",
    sortable: true,
    render: (offer) => getStatusBadge(offer.status),
  },
];

export default function OffersReportingPage() {
  return (
    <div className="p-6 lg:p-8">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold text-foreground">Offers</h1>
          <span className="text-xs font-semibold text-red-600 uppercase">Placeholder (To Update)</span>
        </div>
      </div>

      <DataTable
        data={OFFER_REPORTS}
        columns={columns}
        searchPlaceholder="Search offers..."
        searchKeys={["name", "status"]}
        pageSize={20}
        emptyMessage="No offers found"
      />
    </div>
  );
}
