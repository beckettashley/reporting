"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, TrendingUp, ShoppingCart, CreditCard } from "lucide-react";

const REVENUE_METRICS = [
  { label: "Total Revenue", value: "$12,450", icon: <DollarSign className="w-4 h-4" /> },
  { label: "Average Order Value", value: "$53.20", icon: <ShoppingCart className="w-4 h-4" /> },
  { label: "Total Orders", value: "234", icon: <CreditCard className="w-4 h-4" /> },
  { label: "Growth Rate", value: "+12.5%", icon: <TrendingUp className="w-4 h-4" /> },
];

const REVENUE_BY_PRODUCT = [
  { name: "Premium Wireless Headphones", revenue: "$4,500", orders: 30 },
  { name: "Smart Watch Series X", revenue: "$3,600", orders: 12 },
  { name: "Noise-Cancelling Earbuds", revenue: "$2,250", orders: 25 },
  { name: "Organic Cotton T-Shirt", revenue: "$1,400", orders: 40 },
  { name: "Collagen Peptides Powder", revenue: "$700", orders: 15 },
];

export default function RevenueReportPage() {
  return (
    <div className="p-6 lg:p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-foreground">Revenue Report</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Track your revenue performance and top products.
        </p>
      </div>

      <div className="grid gap-6">
        {/* Metrics */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {REVENUE_METRICS.map((metric) => (
            <Card key={metric.label}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {metric.label}
                </CardTitle>
                <div className="p-2 bg-muted rounded-md">{metric.icon}</div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-foreground">{metric.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Revenue by Product */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Revenue by Product</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col divide-y divide-border">
              {REVENUE_BY_PRODUCT.map((product, index) => (
                <div key={index} className="flex items-center justify-between py-3 first:pt-0 last:pb-0">
                  <div>
                    <p className="text-sm font-medium text-foreground">{product.name}</p>
                    <p className="text-xs text-muted-foreground">{product.orders} orders</p>
                  </div>
                  <span className="text-sm font-semibold text-foreground tabular-nums">{product.revenue}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
