"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const CONVERSION_DATA = [
  { source: "Direct", conversions: 89, rate: "3.2%", revenue: "$4,320" },
  { source: "Google Ads", conversions: 67, rate: "2.8%", revenue: "$3,150" },
  { source: "Meta Ads", conversions: 45, rate: "2.4%", revenue: "$2,890" },
  { source: "Organic", conversions: 33, rate: "1.9%", revenue: "$2,090" },
];

export default function ConversionsReportPage() {
  return (
    <div className="p-6 lg:p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-foreground">Conversions Report</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Detailed breakdown of your conversion performance.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Conversions by Source</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-2 font-medium text-muted-foreground">Source</th>
                  <th className="text-right py-3 px-2 font-medium text-muted-foreground">Conversions</th>
                  <th className="text-right py-3 px-2 font-medium text-muted-foreground">Rate</th>
                  <th className="text-right py-3 px-2 font-medium text-muted-foreground">Revenue</th>
                </tr>
              </thead>
              <tbody>
                {CONVERSION_DATA.map((row) => (
                  <tr key={row.source} className="border-b border-border last:border-0">
                    <td className="py-3 px-2 font-medium text-foreground">{row.source}</td>
                    <td className="py-3 px-2 text-right text-foreground tabular-nums">{row.conversions}</td>
                    <td className="py-3 px-2 text-right">
                      <Badge variant="secondary">{row.rate}</Badge>
                    </td>
                    <td className="py-3 px-2 text-right text-foreground font-medium tabular-nums">{row.revenue}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
