"use client";

const _PAGE_VERSION = 5;

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Zap,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Building2,
  Globe,
} from "lucide-react";

// Step 1: Login schema
const loginSchema = z.object({
  fullName: z.string().min(2, "Full name is required"),
  email: z.string().email("Please enter a valid email"),
});

// Step 2: Company schema
const companySchema = z.object({
  companyName: z.string().min(2, "Company name is required"),
  operatingName: z.string().optional(),
  website: z.string().url("Please enter a valid URL"),
  tosAccepted: z.literal(true, {
    errorMap: () => ({ message: "You must accept the Terms of Service" }),
  }),
  privacyAccepted: z.literal(true, {
    errorMap: () => ({ message: "You must accept the Privacy Policy" }),
  }),
});

type LoginValues = z.infer<typeof loginSchema>;
type CompanyValues = z.infer<typeof companySchema>;

function WelcomePageContent() {
  const [step, setStep] = useState<1 | 2>(1);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [loginData, setLoginData] = useState<LoginValues | null>(null);
  const [usedGoogle, setUsedGoogle] = useState(false);

  const loginForm = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      fullName: "John Demo",
      email: "demo@testbrand.com",
    },
  });

  const companyForm = useForm<CompanyValues>({
    resolver: zodResolver(companySchema),
    defaultValues: {
      companyName: "Test Brand Inc.",
      operatingName: "Test Brand",
      website: "https://testbrand.com",
      tosAccepted: true,
      privacyAccepted: true,
    },
  });

  const handleGoogleAuth = () => {
    setIsGoogleLoading(true);
    setTimeout(() => {
      const googleData = {
        fullName: "John Demo",
        email: "john.demo@gmail.com",
      };
      setLoginData(googleData);
      setUsedGoogle(true);
      setIsGoogleLoading(false);
      setStep(2);
    }, 1000);
  };

  const onLoginSubmit = (data: LoginValues) => {
    setLoginData(data);
    setUsedGoogle(false);
    setStep(2);
  };

  const onCompanySubmit = () => {
    // Just navigate to demo - skip account creation
    window.location.href = "/onboarding";
  };

  const tosAccepted = companyForm.watch("tosAccepted");
  const privacyAccepted = companyForm.watch("privacyAccepted");

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      {/* Left Panel - Brand */}
      <div className="hidden lg:flex flex-col justify-between bg-foreground text-background p-12">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-background rounded-md flex items-center justify-center">
              <Zap className="w-5 h-5 text-foreground" />
            </div>
            <span className="text-xl font-semibold">Matter</span>
          </div>
        </div>

        <div className="space-y-8">
          <h1 className="text-4xl font-bold leading-tight text-balance">
            Lorem ipsum dolor sit amet consectetur
          </h1>
          <p className="text-lg text-background/70 max-w-md">
            Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Ut enim ad minim veniam, quis nostrud exercitation ullamco.
          </p>

          <div className="space-y-4 pt-4">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <span className="text-background/80">Lorem ipsum dolor sit amet</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <span className="text-background/80">Consectetur adipiscing elit</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <span className="text-background/80">Sed do eiusmod tempor</span>
            </div>
          </div>
        </div>

        <p className="text-sm text-background/50">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit
        </p>
      </div>

      {/* Right Panel - Form (Stripe-style layout) */}
      <div className="flex flex-col min-h-screen">
        {/* Mobile Logo */}
        <div className="lg:hidden flex items-center gap-2 px-6 pt-8">
          <div className="w-8 h-8 bg-foreground rounded-md flex items-center justify-center">
            <Zap className="w-5 h-5 text-background" />
          </div>
          <span className="text-xl font-semibold">Matter</span>
        </div>

        {/* Form content - centered vertically */}
        <div className="flex-1 flex flex-col justify-center px-6 py-12 lg:px-16">
          <div className="mx-auto w-full max-w-md">
            {/* Step 1: Login */}
            {step === 1 && (
              <>
                <div className="mb-8">
                  <h2 className="text-2xl font-semibold">Create your account</h2>
                  <p className="text-muted-foreground mt-1">
                    Enter your details to get started
                  </p>
                </div>

                <div className="space-y-6">
                  {/* Primary flow: Email entry first (like Stripe) */}
                  <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Full Name</Label>
                      <Input
                        id="fullName"
                        placeholder="Jane Smith"
                        {...loginForm.register("fullName")}
                      />
                      {loginForm.formState.errors.fullName && (
                        <p className="text-xs text-destructive">
                          {loginForm.formState.errors.fullName.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="jane@company.com"
                        {...loginForm.register("email")}
                      />
                      {loginForm.formState.errors.email && (
                        <p className="text-xs text-destructive">
                          {loginForm.formState.errors.email.message}
                        </p>
                      )}
                    </div>

                    <Button type="submit" className="w-full">
                      <span className="flex items-center gap-2">
                        Continue
                        <ArrowRight className="w-4 h-4" />
                      </span>
                    </Button>
                  </form>

                  {/* Divider */}
                  <div className="flex items-center gap-3">
                    <div className="flex-1 h-px bg-border" />
                    <span className="text-xs text-muted-foreground">Or sign in with</span>
                    <div className="flex-1 h-px bg-border" />
                  </div>

                  {/* Social auth as secondary option (like Stripe) */}
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={handleGoogleAuth}
                    disabled={isGoogleLoading}
                  >
                    {isGoogleLoading ? (
                      <span className="flex items-center gap-2">
                        <span className="w-4 h-4 border-2 border-muted-foreground border-t-transparent rounded-full animate-spin" />
                        Connecting...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        <svg className="w-5 h-5" viewBox="0 0 24 24">
                          <path
                            d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                            fill="#4285F4"
                          />
                          <path
                            d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                            fill="#34A853"
                          />
                          <path
                            d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                            fill="#FBBC05"
                          />
                          <path
                            d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                            fill="#EA4335"
                          />
                        </svg>
                        Google
                      </span>
                    )}
                  </Button>
                </div>
              </>
            )}

            {/* Step 2: Company Details */}
            {step === 2 && (
              <>
                <div className="mb-8">
                  <button
                    onClick={() => setStep(1)}
                    className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back
                  </button>
                  <h2 className="text-2xl font-semibold">Tell us about your business</h2>
                  <p className="text-muted-foreground mt-1">
                    {usedGoogle ? (
                      <>Signed in as <span className="text-foreground font-medium">{loginData?.email}</span></>
                    ) : (
                      <>Continuing as <span className="text-foreground font-medium">{loginData?.email}</span></>
                    )}
                  </p>
                </div>

                <form onSubmit={companyForm.handleSubmit(onCompanySubmit)} className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                      <Building2 className="w-4 h-4" />
                      <span>Company Information</span>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="companyName">
                        Legal Company Name <span className="text-destructive">*</span>
                      </Label>
                      <Input
                        id="companyName"
                        placeholder="Acme Corporation Inc."
                        {...companyForm.register("companyName")}
                      />
                      {companyForm.formState.errors.companyName && (
                        <p className="text-xs text-destructive">
                          {companyForm.formState.errors.companyName.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="operatingName">
                        Operating / Brand Name
                        <span className="text-muted-foreground font-normal ml-1">(optional)</span>
                      </Label>
                      <Input
                        id="operatingName"
                        placeholder="Acme"
                        {...companyForm.register("operatingName")}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="website">
                        <Globe className="w-3.5 h-3.5 inline mr-1.5" />
                        Website URL <span className="text-destructive">*</span>
                      </Label>
                      <Input
                        id="website"
                        placeholder="https://example.com"
                        {...companyForm.register("website")}
                      />
                      {companyForm.formState.errors.website && (
                        <p className="text-xs text-destructive">
                          {companyForm.formState.errors.website.message}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="h-px bg-border" />

                  {/* Agreements */}
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <Checkbox
                        id="tos"
                        checked={tosAccepted}
                        onCheckedChange={(checked) =>
                          companyForm.setValue("tosAccepted", checked === true)
                        }
                      />
                      <label htmlFor="tos" className="text-sm leading-tight cursor-pointer">
                        I agree to the{" "}
                        <a href="#" className="text-primary underline underline-offset-2 hover:no-underline">
                          Terms of Service
                        </a>
                      </label>
                    </div>
                    {companyForm.formState.errors.tosAccepted && (
                      <p className="text-xs text-destructive ml-7">
                        {companyForm.formState.errors.tosAccepted.message}
                      </p>
                    )}

                    <div className="flex items-start gap-3">
                      <Checkbox
                        id="privacy"
                        checked={privacyAccepted}
                        onCheckedChange={(checked) =>
                          companyForm.setValue("privacyAccepted", checked === true)
                        }
                      />
                      <label htmlFor="privacy" className="text-sm leading-tight cursor-pointer">
                        I agree to the{" "}
                        <a href="#" className="text-primary underline underline-offset-2 hover:no-underline">
                          Privacy Policy
                        </a>
                      </label>
                    </div>
                    {companyForm.formState.errors.privacyAccepted && (
                      <p className="text-xs text-destructive ml-7">
                        {companyForm.formState.errors.privacyAccepted.message}
                      </p>
                    )}
                  </div>

                  <Button type="submit" className="w-full">
                    {false ? (
                      <span className="flex items-center gap-2">
                        <span className="w-4 h-4 border-2 border-background border-t-transparent rounded-full animate-spin" />
                        Creating account...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        Create account
                        <ArrowRight className="w-4 h-4" />
                      </span>
                    )}
                  </Button>
                </form>
              </>
            )}
          </div>
        </div>

        {/* Footer — pinned to bottom with subtle background like Stripe */}
        <div className="bg-muted/50 px-6 lg:px-16 py-4">
          <p className="text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <a href="#" className="text-primary hover:underline">
              Sign in
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}

export default function WelcomePage() {
  // TEMPORARY: redirect directly to wizard products step for dev preview
  if (typeof window !== "undefined") {
    window.location.replace("/onboarding?step=6");
    return null;
  }
  return <WelcomePageContent />;
}
